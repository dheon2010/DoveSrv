#version 150

#moj_import <fog.glsl>

// Leather armor atlas shader - FRAGMENT side.
// The slot search happens in the vertex shader now; this stage only samples the texture
// at the already-resolved atlas position (see the .vsh for the atlas layout).

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

in float vertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
flat in vec4 tint;
flat in vec4 litColor;
flat in vec4 slotInfo;
flat in vec2 uvScale;
flat in vec2 uvOff;
flat in vec2 uvNext;

out vec4 fragColor;

// Fragments closer to the camera than this (in blocks) are dropped before any texture work.
// Stops the heavy overdraw lag when the camera (freelook / freecam) sits inside a player's body.
// Raise it if lag remains, lower it (0.0 = off) if armor vanishes too early.
#define NEAR_CULL 0.1
// Closer than this (blocks) the armor is still drawn, but with a cheap single-sample path
// (no animation blend / emissive mask / tint) so camera-inside-body overdraw stays fast.
#define NEAR_FAST 1.5

void main() {
    if (vertexDistance < NEAR_CULL) {
        discard;
    }

    float mode = slotInfo.x;

    if (vertexDistance < NEAR_FAST && mode > 1.5) {
        vec4 fast = texture(Sampler0, texCoord0 * uvScale + uvOff) * litColor * ColorModulator;
        if (fast.a < 0.1) {
            discard;
        }
        fragColor = fast;
        return;
    }

    vec4 color;

    if (mode < 0.5) {
        // not the custom atlas: vanilla leather armor
        color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    } else if (mode < 1.5) {
        // custom atlas but this dye colour has no slot: slot 0 (plain leather)
        color = texture(Sampler0, texCoord0 * uvScale) * vertexColor * ColorModulator;
    } else {
        vec2 coords = texCoord0 * uvScale + uvOff;
        float emissive = slotInfo.z;
        float flagG = slotInfo.w;
        vec4 vtc = vertexColor;

        float mask = 0.0;
        if (emissive == 1.0) {
            mask = texture(Sampler0, vec2(coords.x + uvScale.x, coords.y)).a;
        }

        if (flagG == 1.0) {
            if (emissive > 1.0) {
                vtc = tint;
            } else if (emissive == 1.0) {
                if (mask != 0.0) {
                    vtc = tint * mask;
                }
            }
        } else if (flagG == 0.0) {
            if (emissive > 1.0) {
                vtc = vec4(1.0);
            } else if (emissive == 1.0 && mask != 0.0) {
                vtc = vec4(mask);
            } else {
                vtc = litColor;
            }
        } else {
            vtc = litColor;
        }

        vec4 armor = texture(Sampler0, coords);
        if (slotInfo.y > 0.0) {
            armor = mix(armor, texture(Sampler0, texCoord0 * uvScale + uvNext), slotInfo.y);
        }
        color = armor * vtc * ColorModulator;
    }

    if (color.a < 0.1) {
        discard;
    }
    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}
