#version 150
#moj_import <light.glsl>

// Leather armor atlas shader - VERTEX side.
// The slot lookup (which atlas cell belongs to this dye colour, animation frame, emissive flags)
// used to run for EVERY PIXEL in the fragment shader (up to ~890 texel fetches per pixel).
// It now runs once per VERTEX here, and the fragment shader only reads the results (flat outputs).
//
// Atlas layout (unchanged):
// Row 0 : original slots (1 frame each). Rows 1+ : extra slots, frames laid out horizontally.
// Slot header (first 3 pixels of the slot's first column, top row):
//   p0 = dye colour key, p1 = (frames, speed, interpolate), p2 = (emissive, flagG, 0)
// emissive == 1 : the column right after every frame holds the full-bright mask.
#define V1 32
#define V2 50

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;
uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform vec3 Light0_Direction;
uniform vec3 Light1_Direction;
uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec2 texCoord1;
out vec4 normal;
flat out vec4 tint;
flat out vec4 litColor;
// x: 0 = plain vanilla texture, 1 = atlas but no slot matched, 2 = slot matched
// y: frame interpolation factor (0 = none), z: emissive flag, w: flagG
flat out vec4 slotInfo;
flat out vec2 uvScale;
flat out vec2 uvOff;
flat out vec2 uvNext;

void main() {
    vec4 texel = texelFetch(Sampler2, UV2 / 16, 0);
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    vertexDistance = length((ModelViewMat * vec4(Position, 1.0)).xyz);
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color) * texel;
    litColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, vec4(1.0)) * texel;
    tint = Color;
    texCoord0 = UV0;
    texCoord1 = UV1;
    normal = ProjMat * ModelViewMat * vec4(Normal, 0.0);

    slotInfo = vec4(0.0);
    uvScale = vec2(1.0);
    uvOff = vec2(0.0);
    uvNext = vec2(0.0);

    // atlas marker pixel
    if (texelFetch(Sampler0, ivec2(0, 1), 0) == vec4(1.0)) {
        ivec2 atlasSize = textureSize(Sampler0, 0);
        float armorAmount = float(atlasSize.x) / (float(V1) * 4.0);
        float rowAmount = float(atlasSize.y) / (float(V1) * 2.0);
        int columns = int(armorAmount);
        int rows = int(rowAmount);
        float hOffset = 1.0 / armorAmount;
        float vOffset = 1.0 / rowAmount;

        uvScale = vec2(hOffset, vOffset);
        slotInfo.x = 1.0;

        bool found = false;
        for (int b = 0; b < rows && !found; b++) {
            for (int i = 1; i < columns && !found; i++) {
                vec4 customColor = texelFetch(Sampler0, ivec2(V1 * 4 * i, 64 * b), 0);
                if (Color == customColor) {
                    found = true;
                    slotInfo.x = 2.0;

                    vec4 animInfo = texelFetch(Sampler0, ivec2(V1 * 4 * i + 1, 64 * b), 0);
                    vec4 props = texelFetch(Sampler0, ivec2(V1 * 4 * i + 2, 64 * b), 0);
                    vec3 anim = floor(animInfo.rgb * (animInfo.a * 255.0) + 0.5);
                    vec3 prop = floor(props.rgb * (props.a * 255.0) + 0.5);
                    slotInfo.z = prop.r;
                    slotInfo.w = prop.g;

                    uvOff = vec2(hOffset * float(i), vOffset * float(b));
                    if (anim.r > 1.5) {
                        float stride = (prop.r == 1.0 && prop.g == 0.0) ? 2.0 : 1.0;
                        float clock = GameTime * float(V2) * anim.g;
                        float timer = floor(mod(clock, anim.r));
                        uvOff.x += hOffset * stride * timer;
                        if (anim.b > 0.5) {
                            slotInfo.y = fract(clock);
                            uvNext = uvOff;
                            uvNext.x += hOffset * stride * (mod(timer + 1.0, anim.r) - timer);
                        }
                    }
                }
            }
        }
    }
}
