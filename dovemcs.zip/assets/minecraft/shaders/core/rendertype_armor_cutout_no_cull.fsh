#version 150
#moj_import <fog.glsl>
#moj_import <light.glsl>

// Leather armor atlas shader.
// Row 0 : original slots (1 frame each). Rows 1+ : extra slots, frames laid out horizontally.
// Slot header (first 3 pixels of the slot's first column, top row):
//   p0 = dye colour key, p1 = (frames, speed, interpolate), p2 = (emissive, 0, 0)
// emissive == 1 : the column right after every frame holds the full-bright mask.
#define V1 32
#define V2 50
#define V3 texelFetch(Sampler0, ivec2(0, 1), 0)==vec4(1)

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;
uniform float GameTime;
uniform vec3 Light0_Direction;
uniform vec3 Light1_Direction;

in float vertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;
in vec4 normal;
flat in vec4 tint;
flat in vec3 vNormal;
flat in vec4 texel;

out vec4 fragColor;

void main() {
    ivec2 atlasSize = textureSize(Sampler0, 0);
    float armorAmount = atlasSize.x / (V1 * 4.0);
    float rowAmount = atlasSize.y / (V1 * 2.0);
    int columns = int(armorAmount);
    int rows = int(rowAmount);

    vec2 coords = texCoord0;
    coords.x /= armorAmount;
    coords.y /= rowAmount;

    vec4 color;
    if (V3) {
        vec4 textureProperties = vec4(0);
        vec4 customColor = vec4(0);
        float h_offset = 1.0 / armorAmount;
        float v_offset = 1.0 / rowAmount;
        vec2 nextFrame = vec2(0);
        float interpolClock = 0.0;
        vec4 vtc = vertexColor;
        bool found = false;

        for (int b = 0; b < rows && !found; b++) {
            for (int i = 1; i < columns && !found; i++) {
                customColor = texelFetch(Sampler0, ivec2(V1 * 4 * i, 64 * b), 0);
                if (tint == customColor) {
                    found = true;
                    coords.x += h_offset * float(i);
                    coords.y += v_offset * float(b);
                    vec4 animInfo = texelFetch(Sampler0, ivec2(V1 * 4 * i + 1, 64 * b), 0);
                    animInfo.rgb *= animInfo.a * 255.0;
                    textureProperties = texelFetch(Sampler0, ivec2(V1 * 4 * i + 2, 64 * b), 0);
                    textureProperties.rgb *= textureProperties.a * 255.0;
                    if (animInfo.r > 1.5) {
                        float stride = (textureProperties.r == 1.0 && textureProperties.g == 0.0) ? 2.0 : 1.0;
                        float clock = GameTime * V2 * animInfo.g;
                        float timer = floor(mod(clock, animInfo.r));
                        coords.x += h_offset * stride * timer;
                        if (animInfo.b > 0.5) {
                            interpolClock = fract(clock);
                            nextFrame = coords;
                            nextFrame.x += h_offset * stride * (mod(timer + 1.0, animInfo.r) - timer);
                        }
                    }
                }
            }
        }

        if (textureProperties.g == 1.0) {
            if (textureProperties.r > 1.0) {
                vtc = tint;
            } else if (textureProperties.r == 1.0) {
                if (texture(Sampler0, vec2(coords.x + h_offset, coords.y)).a != 0.0) {
                    vtc = tint * texture(Sampler0, vec2(coords.x + h_offset, coords.y)).a;
                }
            }
        } else if (textureProperties.g == 0.0) {
            if (textureProperties.r > 1.0) {
                vtc = vec4(1);
            } else if (textureProperties.r == 1.0) {
                if (texture(Sampler0, vec2(coords.x + h_offset, coords.y)).a != 0.0) {
                    vtc = vec4(1) * texture(Sampler0, vec2(coords.x + h_offset, coords.y)).a;
                } else {
                    vtc = minecraft_mix_light(Light0_Direction, Light1_Direction, vNormal, vec4(1)) * texel;
                }
            } else {
                vtc = minecraft_mix_light(Light0_Direction, Light1_Direction, vNormal, vec4(1)) * texel;
            }
        } else {
            vtc = minecraft_mix_light(Light0_Direction, Light1_Direction, vNormal, vec4(1)) * texel;
        }

        vec4 armor = texture(Sampler0, coords);
        if (interpolClock > 0.0) {
            armor = mix(armor, texture(Sampler0, nextFrame), interpolClock);
        }
        if (found) {
            color = armor * vtc * ColorModulator;
        } else {
            color = armor * vertexColor * ColorModulator;
        }
    } else {
        color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    }

    if (color.a < 0.1) {
        discard;
    }
    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}
